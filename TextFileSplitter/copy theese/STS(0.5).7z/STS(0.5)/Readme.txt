Simple Text Splitter 0.5.322

A simple splitter for text based files (txt, log, m3u, pls, etc.).

Change Log:
--0.5--
-Improved interface
-Improved file loading performance
-Added Unicode support
-Added drag and drop support
-Added About window
-Added new icons
-Fixed problems related to stopping splitting process
-Fixed a couple of memory leaks
-Some minor fixes/improvements

--0.4--
-First public release