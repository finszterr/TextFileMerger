********************************************************************
			Jaffnasoft Software Series 
********************************************************************
Application	:JS Text File Merger 
Version		: 1.0.0
Date		: 05 August 2004
********************************************************************

JS Text File Merger 1.0 is a 100 % freeware. Any one can use it for any purpose.
Much care was taken to avoid any harm to any thing. 

Any one can use this piece of software at his/her  own risk. We disclaim any responsibility
for any damage. 

Any bugs or wish lists can be reported to developer@jaffnasoft.com

Your feedback is welcome at feedback@jaffnasoft.com

Enjoy
*************************************************************************